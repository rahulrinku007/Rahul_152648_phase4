
package com.cg.spring.PaymentWalletSpring.dto;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Embeddable;

@Embeddable
public class Wallet implements Serializable {

	private double balance;

	public Wallet(double balance) {
		super();
		this.balance = balance;

	}

	@Override
	public String toString() {
		return "Wallet [balance=" + balance + "]";
	}

	public Wallet() {
		super();
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

}

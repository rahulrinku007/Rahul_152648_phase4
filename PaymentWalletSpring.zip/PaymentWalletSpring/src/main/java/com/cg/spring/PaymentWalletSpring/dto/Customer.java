package com.cg.spring.PaymentWalletSpring.dto;

import java.time.LocalDate;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Customer {
	@Id
	private String number;
	private String name;
	private String transaction;
	@Embedded
	private Wallet wallet;
	public Customer() {
		// TODO Auto-generated constructor stub
	}

	public Customer(String number, String name, Double balance, String transaction) {
		super();
		this.number = number;
		this.name = name;
		this.transaction = transaction;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTransaction() {
		return transaction;
	}

	public void setTransaction(String transaction) {
		this.transaction = transaction;
		
	}

	public Wallet getWallet() {
		return wallet;
	}

	public void setWallet(Wallet wallet) {
		this.wallet = wallet;
	}

	
}
